$(function(){
	//倒计时
	function GetRTime(){
	   var EndTime= new Date('2016/06/09 23:59:59');
	   var NowTime = new Date();
	   var t =EndTime.getTime() - NowTime.getTime();
	   var d=Math.floor(t/1000/60/60/24);
	   var h=Math.floor(t/1000/60/60%24);
	   var m=Math.floor(t/1000/60%60);
	   var s=Math.floor(t/1000%60);
	
	   $("#Days").html(d);
	   $("#Hrs").html(h);
	   $("#Mins").html(m);
	   $("#Secs").html(s);
	}
	setInterval(GetRTime,0);
	
	var activityId=getUrlParam('aid');
    var hitType=getUrlParam('hitType');
	var timestamp=new Date().getTime();
    timestamp=parseInt(timestamp/1000);
    var nonceStr='Wm3WZYTPz0wzccmW',
            url=location.href.split('#')[0],
            signature='',appId;
    var url=escape(url);
    console.log(url);
	$.ajax({
        type:'GET',
        async:'true',
        url:'http://www.higoin.com/wechat/getWechatConfig.action?merchantId=204&timestamp='+timestamp+'&nonceStr='+nonceStr+'&url='+url,
        dataType:'jsonp',
        data:'',
        jsonp:'callback',
        success:function(result) {
            console.log(result);
            appId=result.appId;
            signature=result.signature;
            wx.config({
                debug: false,
                appId:appId,
                timestamp: timestamp,
                nonceStr: nonceStr,
                signature: signature,
                jsApiList: [
                    'checkJsApi',
                    'onMenuShareTimeline',
                    'onMenuShareAppMessage',
                    'onMenuShareQQ',
                    'onMenuShareWeibo',
                    'hideMenuItems',
                    'showMenuItems',
                    'hideAllNonBaseMenuItem',
                    'showAllNonBaseMenuItem',
                    'translateVoice',
                    'startRecord',
                    'stopRecord',
                    'onRecordEnd',
                    'playVoice',
                    'pauseVoice',
                    'stopVoice',
                    'uploadVoice',
                    'downloadVoice',
                    'chooseImage',
                    'previewImage',
                    'uploadImage',
                    'downloadImage',
                    'getNetworkType',
                    'openLocation',
                    'getLocation',
                    'hideOptionMenu',
                    'showOptionMenu',
                    'closeWindow',
                    'scanQRCode',
                    'chooseWXPay',
                    'openProductSpecificView',
                    'addCard',
                    'chooseCard',
                    'openCard'
                ]
            });
            wx.ready(function(){
                /****************/
                /****************/
                var mix_url='http://liveapp.1paiclub.com/rest/lightApp/redirect?aid='+activityId+'&hitType=2';
                var shareData = {
                    title: "美食PK",
                    desc: "百万礼券等你来",
                    link: mix_url,
                    imgUrl: 'http://liveapp.1paiclub.com/lightapp/lhhd/images/share_img.jpg',
                    success: function (res) {

                    }
                };
                wx.onMenuShareAppMessage(shareData);
                wx.onMenuShareTimeline(shareData);
                wx.onMenuShareQQ(shareData);
                wx.onMenuShareWeibo(shareData);
            })
        }
    });
    var responseData = $.ajax({
        url: "http://liveapp.1paiclub.com/rest/lightApp/config",
        async: false,
        type : "GET",
        dataType : "json",
        data: {"activityId":activityId, "hitType":hitType}
    }).responseText;
    responseData=eval("("+responseData+")");
    responseData = responseData.data;
    var token= responseData.token;
    
    var awardsList=[];
    var phone= $.cookies.get(activityId+'phone');
    var vote_choose = '';
    if(phone!=null){//手机号不为空即输入过手机号
    	loadResult();
    }else{
    	$("#iWant_vote").click(function(){
			var html ='<div id="vote_message">';
    			html+='	<div class="vote_title">';
    			html+='		<img src="images/alert_title.png" />';
		    	html+='		<div class="vote_choose">';
		    	html+='			<div class="vote_chooseimg fl checked" data-value="1">';
		    	html+='				<img src="images/alert_hot_pot.png"/>';
		    	html+='			</div>';
		    	html+='			<div class="vote_chooseimg fl" data-value="2">';
		    	html+='				<img src="images/alert_lobster.png"/>';
		    	html+='			</div>';
		    	html+='		</div>';
	    		html+='	</div>';
	    		html+='	<div class="vote_phone">';
	    		html+='		<input type="tel" class="phone" id="phone" placeholder="填写手机号" />';
	    		html+='		<button id="submit">立即投票</button>';
	    		html+='	</div>';
	    		html+='	<div class="close">';
	    		html+='		<img src="images/close.png" />';
	    		html+='	</div>';
    			html+='</div>';
			layer.open({
			    content: html,
			    className:'vote_window',
			    shadeClose:false,
			    success:function(elem){
			    	alertBackshow();
			    	$(".close").click(function(){
						alertBackhide();
						layer.closeAll();
					});
					$(".vote_chooseimg").click(function(){
						$(".vote_chooseimg").removeClass("checked");
						$(this).addClass("checked");
					});
					$("#submit").click(function(){
						phone=$('#phone').val();
			            if(phone==''){
			                alert('手机号不能为空!');
			                return false;
			            }
						if(!validatemobile(phone)) return false;
						vote_choose = $(".checked").attr("data-value");
						submitResult();
					})
			    },
			    end:function(){
				    alertBackhide();
				} 
			});
		});
		
    }
    function submitResult(){
    	$.ajax({
    		type: "POST",
			url: "http://liveapp.1paiclub.com/rest/lightApp/data/submit",
			dataType: "json",
			data: {
				"activityId":activityId,
				"phone": phone,
				"statistic":2,
				"param2": vote_choose,
			},
			success:function(result){
				console.log(result);
				if(result.code!=0) {
                    alert(result.msg);
                }else{
                	var html ='<div class="vote_success" id="vote_success">';
		    			html+='	<p>投票成功</p>';
		    			html+='	<p>恭喜您获得礼券包</p>';
		    			html+='	<div class="close">';
			    		html+='		<img src="images/close.png" />';
			    		html+='	</div>';
				    	html+='</div>';
			    	layer.open({
					    content: html,
					    className:'vote_window',
					    shadeClose:false,
					    success:function(elem){
					    	alertBackshow();
					    	$(".close").click(function(){
								alertBackhide();
								layer.closeAll();
							});
					    },
					    end:function(){
						    alertBackhide();
						}
					});
                }
				loadResult();
			}
    	})
    }
    function loadResult(){
		$.ajax({
			type: "POST",
			url: "http://liveapp.1paiclub.com/rest/lightApp/award/personal/list",
			dataType: "json",
			data: {
				'activityId': activityId,
                'pageNo': 1,
                'limit': 500,
                'searchText': phone
			},
			success:function(result) {
				if(result.code!=0) {
                    alert('数据处理失败!');
                    return false;
                }
                if(result.data.length>0){//提交过,数据库有数据,取得数据展示
                    for(var i= 0,j= 0,k=0;i<result.data.length;i++){
                        awardsList[j] = {};
                        awardsList[j]['prizeName'] = result.data[i].prizeName;
                        awardsList[j].merchantName = result.data[i].prizeInfo;
                        awardsList[j].merchantCode = result.data[i].merchantCode;
                        j++;
                    }
                    awardsList=JSON.stringify(awardsList.reverse());
                    $.cookies.set(activityId + 'awardsList',awardsList);//获取的奖品
                    $.cookies.set(activityId+'phone',phone);
                    showCouponslist();
                }else{
                	$.ajax({
					type: "POST",
					url: "http://liveapp.1paiclub.com/rest/lightApp/award/scoreLottery",
					dataType: "json",
					data: {
						"activityId":activityId,
						"token": token,
						"score": -1,
						"activityType": null
					},
					success:function(result){
						console.log(result);
						if(result.code!=0){
		                    alert('获取数据失败!');
		                }else{
		                	for(var i= 0,j= 0,k=0;i<result.data.length;i++){
		                        if(result.data[i].remainNumber>0) {
		                            awardsList[j] = {};
		                            awardsList[j].merchantId = parseInt(result.data[i].merchantId);
		                            awardsList[j]['prizeName'] = result.data[i].name;
		                            awardsList[j].merchantName = result.data[i].merchantName;
		                            awardsList[j].merchantCode = result.data[i].merchantCode;
		                            j++;
		                        }
		                    }
		                }
		                if(awardsList.length>0){
		                	awardsList=JSON.stringify(awardsList);
		                	console.log(awardsList);
		                    $.ajax({
		                        type: 'POST',
		                        url: "http://liveapp.1paiclub.com/rest/lightApp/award/submit/list",
		                        dataType: 'json',
		                        data: {
		                            "activityId": activityId,
		                            "phone": phone,
		                            "token": token,
		                            "awards":awardsList
		                        },
		                        success: function (result) {
		                        	console.log(result);
		                            if(result.code!=0) {
		                                alert(result.msg);
		                                return false;
		                            }else{
										$.cookies.set(activityId+'phone',phone);
		                                $.cookies.set(activityId + 'awardsList',awardsList);//获取的奖品写入缓存(如果没有也照样写入缓存)
		                            	showCouponslist();
		                            }
		                        }
		                    })
		                }else{//奖品发完
		                    $('#coupon ul').append('奖品已经被领完了')
		                }
					}
					});
                }
			}
		});
		$.ajax({
			type: "GET",
			url: "http://liveapp.1paiclub.com/rest/lightApp/data/statistic",
			dataType: "json",
			data: {
				'activityId': activityId,
				'phone': phone
			},
			success:function(result) {
				if(result.code!=0) {
                    alert('数据处理失败!');
                    return false;
                }
				if(result.data.counter.total){
					$(".hot_pot,.lobster").css("background","none");
					var hot_pot_percent = ((result.data.ratio_1['1']||0)*100).toFixed(0);
					var lobster_percent = ((result.data.ratio_1['2']||0)*100).toFixed(0);
					$("#hot_pot_percent").html(hot_pot_percent);
					$("#lobster_percent").html(lobster_percent);
					$(".percent").html("%");
					var array=[];
					for(o in result.data.user_vote){
						array.push(o);
					}
					if(array[0]==1){
						$(".ilike_1").removeClass("hide");
					}else if(array[0]==2){
						$(".ilike_2").removeClass("hide");
					}
					
				}
				
			}
		});
    }
    function showCouponslist(){
    	var awardsList=$.cookies.get(activityId + 'awardsList');
    	$("#iWant_vote").hide();
    	$("#coupon").show();
    	var map = new Hashtable();
        var logoQrList=[
            //火锅组
			{'name':1,date_use:'领取之日起1个月内有效',m_code:'738'},//好骨气火锅
			{'name':2,date_use:'领取之日起2个月内有效',m_code:'373'},//鼎玖重庆老火锅
			{'name':3,date_use:'领取之日起1个月内有效',m_code:'377'},//韩林碳烤
			{'name':4,date_use:'领取之日起1个月内有效',m_code:'153'},//小山城麻辣香锅
			//龙虾组
            {'name':5,date_use:'领取之日起1个月内有效',m_code:'386'},//朱小乐
            {'name':6,date_use:'领取之日起1个月内有效',m_code:'544'},//虾趣龙虾
            {'name':7,date_use:'领取之日起1个月内有效',m_code:'132'},//7龙虾
            {'name':8,date_use:'领取之日起2个月内有效',m_code:'337'},//圆苑餐厅
        ];
        for(var i=0;i<logoQrList.length;i++){
            map.add(logoQrList[i].m_code, logoQrList[i]);
        }
        $('#coupon ul').empty();
    	var couponsItems='';
    	console.log(awardsList);
    	for(var i=0;i<awardsList.length;i++){
    		var value = awardsList[i].prizeName.replace(/[^0-9]/ig,"");
    		var name = awardsList[i].prizeName.replace(/[0-9]/ig,"");
			couponsItems+='<li>'+
							'<img src="images/coupon_back.png" />'+
							'<div class="coupon_left">'+
								'<table>'+
									'<tr>'+
										'<td>'+
											'<img src="images/store_info/'+map.items(awardsList[i].merchantCode).name+'.png" />'+
										'</td>'+
										'<td>'+
											'<p class="coupon_title">'+
												'<span class="coupon_title_number">'+value+'</span><span>'+name+'</span>'+
											'</p>'+
											'<p class="coupon_time">'+
												'使用期限&nbsp;&nbsp;<span>'+map.items(awardsList[i].merchantCode).date_use+'</span>'+
											'</p>'+
										'</td>'+
									'</tr>'+
								'</table>'+
							'</div>'+
							'<div class="coupon_right">'+
								'<table>'+
									'<tr>'+
										'<td data_value="'+awardsList[i].prizeName+'" data_src="'+map.items(awardsList[i].merchantCode).name+'">立即查看</td>'+
									'</tr>'+
								'</table>'+
							'</div>'+
						'</li>'
		}
    	$('#coupon ul').append(couponsItems);
    	$('#coupon ul li .coupon_right td').bind('click',function(){
            var dataSrc=$(this).attr('data_src');
            var dataValue=$(this).attr('data_value');
            var html ='<img class="merchant" id="merchant" src="images/store_info/'+dataSrc+'.png" />';
            	html+='<p class="QR_code_title" id="QR_code_title">'+dataValue+'</p>';
            	html+='<img class="merchant_QR_code" id="merchant_QR_code" src="images/store_info/'+dataSrc+'_1.jpg"/>';
            	html+='<p>长按识别二维码关注</p>';
            layer.open({
			    content: html,
			    className:'alert_QR_code_window',
			    shadeClose:true,
			    success: function(elem){
				    alertBackshow();
				},
			    end:function(){
				    alertBackhide();
				}      
			});	
        })
    }
    
    
	var currentscroll="";
	$(".pkbtn").click(function(){
		currentscroll=$(window).scrollTop();
		var id = $(this).attr("id");
		var detailList=[
			//火锅组
			{'name':1,text:'交通相对比较便捷，装修简单大方环境优雅，非常适合朋友家庭小聚，适宜情侣约会、家庭聚会、朋友聚餐、随便吃吃。',m_name:'好骨气'},//好骨气火锅
			{'name':2,text:'鼎玖重庆老火锅餐厅是一家经营原汁原味的重庆火锅的餐饮企业，公司由时尚潮人创办于2011年9月，以结合时尚、潮流、健康的主题，特色经典重庆口味、细致热情的服务深受广大消费者的喜爱。开业以来业务稳步发展，力求成为沪上知名潮人火锅代表。 餐厅锅底原料由重庆远道而来，由重庆火锅传人特别熬制，店里中国风的装修风格与时尚的HIGH乐形成另类混搭风。多种精品菜色深得魔都潮人和宅男宅女的喜爱。 《鼎玖》重庆老火锅！舌尖上跳动的中国美味，无辣不欢！ 突破需要沉淀，经过多年的经验积累与市场考验，我们秉承“以食为尊”的菜品研发理念，传承经典重庆火锅的精髓，在制作新潮和特色菜上有独到见解，在每一款菜肴的出品上延续着原汁原味的传统风味，并融合地域复合口味及创新做法，满足广大顾客多样化的需求。',m_name:'鼎玖'},//鼎玖重庆老火锅
			{'name':3,text:'忆泡菜酸辣甜，听拌饭滋滋响，闻木炭烤肉香，品韩国真露酒。韩林是一家全国连锁韩式烤肉品牌，1999年成立上海韩林餐饮有限公司，分别在深圳、成都、武汉、郑州、南京、苏州、杭州、宁波、绍兴等地开设50余家分店。甜、酸、辣是韩国料理口味的特点，代表性的有牛排、冷面、石锅拌饭。这里的调味牛排选用秘制酱汁腌制，经过现代化工艺处理，口感鲜嫩、味道独特，蘸上韩林秘制调料，包上生菜，配上精美的韩式开胃小菜，相信定能令你回味无穷。',m_name:'韩林烤肉'},//韩林碳烤
			{'name':4,text:'麻辣香锅源于川西缙云山土家风味，香锅底料由三十多种香料密制而成。区别于传统涮锅，香锅无汤底，不点火，而是将您喜爱的菜肴与秘制底料一起旺火快炒。可自由搭配各种菜蔬、肉类、海鲜等，辣度可轻可重，集鲜辣、香辣、麻辣融入一锅，上桌即可开食。',m_name:'小山城'},//小山城麻辣香锅
			//龙虾组
            {'name':5,text:'打造魔都第一小龙虾品牌 你不敢争，我来“蒸”；你不做主，我做“煮”。<br />店铺环境高大上，首创矿泉水煮小龙虾。个头从小、中、大号全都有，都是来自南京周边无污染水域的稻田虾。<br />笼屉清蒸的做法最能体现龙虾的原汁原味，还配有麻辣和姜醋两种蘸料。<br />还有9种酒腌制的独孤酒醉龙虾，其中就有山西名酒汾酒哦。像什么番茄炒蛋、咖喱、奶香等等新式口味的龙虾，可谓健康美味两不误。',m_name:'朱小乐'},//朱小乐
            {'name':6,text:'盱眙虾趣龙虾城 08年开业至今，生意仍长期火爆，一到饭点便座无虚席，美味程度可见一斑。<br />主推三款特色龙虾：“金牌十三香精品龙虾”、“黄焖龙虾”、“特色秘制龙虾”。<br />金牌十三香精品龙虾用的是个头最大的小龙虾。底料的“十三香”里包括30多种香料药材，其中还加了夏枯草，所以吃多了也不怕上火。用骨头汤熬煮底料，加入特制的豆瓣酱和菜籽油，味道浑厚，透着股鲜香，又不会掩盖虾肉本身的味道。<br />“黄焖龙虾”有点“咖喱味儿”，汤汁很鲜，带着丝丝甜味，里面还加了软糯的年糕。<br />“特色秘制龙虾”去了虾头更加入味，烹煮的过程添加了大蒜和孜然等佐料，咸鲜微辣，回味甚浓。',m_name:'虾趣'},//虾趣龙虾
            {'name':7,text:'吃货聚集地，时尚潮人“聚乐部”！新鲜的食材搭配健康的烹饪方法，使味蕾得到绝妙的体验！这里有美食、有美食、有良辰、可日天，还不赶快一起来加入我们？',m_name:'7龙虾'},//7龙虾
            {'name':8,text:'上海圆苑餐饮管理有限公司创立于1999年，现已是拥有九家分店的大型规模连锁经营美食中心。店内装璜突显浓厚的欧洲现代文化气息，每家分店又各具特色风格，是洽谈商务、庆功祝酒、宴请亲朋的上佳场所。<br />公司经营传统的本帮经典菜肴兼精美粤菜，随着四季气候的更替科学烹饪颇具特色的时令菜肴，特别是由本店烧制而成的“红烧肉”油而不腻，酥而不烂，广受顾客好评。',m_name:'圆苑'},//圆苑餐厅
        ];
        var html = '';
		if(id=="pk_hot_pot"){
			$("#merchant_top").attr('src','images/hot_pot_top.png');
			for(var i=0;i<=3;i++){
				html+= '<li>';
			    html+= '	<div class="merchant_list_title">';
			    html+= '		<div>';
			    html+= '			<img src="images/store_info/'+detailList[i].name+'.png" />';
			    html+= '			<div class="line"></div>';
			    html+= '			<h1>'+detailList[i].m_name+'</h1>';
			    html+= '		</div>';
			    html+= '	</div>';
			    html+= '	<img class="merchant_list_img" src="images/store_info/'+detailList[i].name+'_2.jpg"/>';
			    html+= '	<p class="merchant_list_txt">'+detailList[i].text+'</p>';
			    html+= '</li>';
			}
		}else if(id=="pk_lobster"){
			$("#merchant_top").attr('src','images/lobster_top.png');
			for(var i=4;i<=7;i++){
				html+= '<li>';
			    html+= '	<div class="merchant_list_title">';
			    html+= '		<div>';
			    html+= '			<img src="images/store_info/'+detailList[i].name+'.png" />';
			    html+= '			<div class="line"></div>';
			    html+= '			<h1>'+detailList[i].m_name+'</h1>';
			    html+= '		</div>';
			    html+= '	</div>';
			    html+= '	<img class="merchant_list_img" src="images/store_info/'+detailList[i].name+'_2.jpg"/>';
			    html+= '	<p class="merchant_list_txt">'+detailList[i].text+'</p>';
			    html+= '</li>';
			}
		}
		$("#merchant_list").html(html);
		$(".main_page").hide();
		$(".page_1").show();
		$('body,html').animate({scrollTop : 0}, 0);
	})
	$("#merchant_close").click(function(){
		$(".page_1").hide();
		$(".main_page").show();
		$('body,html').animate({scrollTop : currentscroll}, 0);
	})
})
function alertBackshow(){
	$('body,html').css("overflow","hidden");
	$('body').on('touchmove', function (event) {
       event.preventDefault();
    });
}
function alertBackhide(){
	$('body,html').css("overflow","");
	$('body').unbind('touchmove');
}
function validatemobile(inputString){
    var partten = /^1[3,5,7,8]\d{9}$/;
    if(partten.test(inputString))
    {
        return true;
    }
    else
    {
        alert('请输入正确的手机号码');
        return false;
    }
}
function getUrlParam(name){
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null){
        return unescape(r[2]);
    }
    return "";
}